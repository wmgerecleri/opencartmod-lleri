<?php
// Heading
$_['heading_title']    = 'WMG Gemini AI Ürün Açıklama';

// Text
$_['text_extension']   = 'Modüller';
$_['text_success']     = 'Başarı: Gemini açıklama modülü güncellendi!';
$_['text_edit']        = 'Gemini Açıklama Modülü Düzenle';
$_['text_enabled']     = 'Etkin';
$_['text_disabled']    = 'Devre Dışı';

// Entry
$_['entry_api_key']    = 'Gemini API Anahtarı';
$_['entry_status']     = 'Durum';

// Help
$_['help_api_key']     = 'Google AI Studio\'dan aldığınız Gemini API anahtarını girin.';

// Error
$_['error_permission'] = 'Uyarı: Bu modülü değiştirme yetkiniz yok!';
$_['error_api_key']    = 'API Anahtarı gerekli!';

// Button
$_['button_save']      = 'Kaydet';
$_['button_cancel']    = 'İptal';