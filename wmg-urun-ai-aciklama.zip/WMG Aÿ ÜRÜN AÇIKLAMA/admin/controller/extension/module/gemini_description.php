<?php
class ControllerExtensionModuleGeminiDescription extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/gemini_description');
        $this->document->setTitle($this->language->get('heading_title'));
        
        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_gemini_description', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['api_key'])) {
            $data['error_api_key'] = $this->error['api_key'];
        } else {
            $data['error_api_key'] = '';
        }

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/gemini_description', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['action'] = $this->url->link('extension/module/gemini_description', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        if (isset($this->request->post['module_gemini_description_api_key'])) {
            $data['module_gemini_description_api_key'] = $this->request->post['module_gemini_description_api_key'];
        } else {
            $data['module_gemini_description_api_key'] = $this->config->get('module_gemini_description_api_key');
        }

        if (isset($this->request->post['module_gemini_description_status'])) {
            $data['module_gemini_description_status'] = $this->request->post['module_gemini_description_status'];
        } else {
            $data['module_gemini_description_status'] = $this->config->get('module_gemini_description_status');
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/gemini_description', $data));
    }

    public function generateDescription() {
        $json = array();
        
        try {
            // API key kontrolü
            $api_key = $this->config->get('module_gemini_description_api_key');
            error_log('API Key kontrolü: ' . (!empty($api_key) ? 'Mevcut' : 'Boş'));
            
            if (!$this->config->get('module_gemini_description_status')) {
                $json['error'] = 'Modül aktif değil!';
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            }
            
            if (empty($api_key)) {
                $json['error'] = 'API anahtarı tanımlanmamış!';
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            }
            
            if (!isset($this->request->post['product_id'])) {
                $json['error'] = 'Ürün ID bulunamadı!';
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            }
            
            $product_id = (int)$this->request->post['product_id'];
            error_log('İşlem yapılan ürün ID: ' . $product_id);
            
            $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
            
            if (!$product_query->num_rows) {
                $json['error'] = 'Ürün bulunamadı! ID: ' . $product_id;
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            }
            
            $product_info = $product_query->row;
            
            $description_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_description WHERE product_id = '" . (int)$product_id . "' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
            
            if (!$description_query->num_rows) {
                $json['error'] = 'Ürün açıklaması bulunamadı!';
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            }
            
            $product_description = $description_query->row;
            error_log('Ürün adı: ' . $product_description['name']);
            
            $prompt = "Ürün Adı: " . $product_description['name'] . "\n";
            $prompt .= "Model: " . $product_info['model'] . "\n";
            
            if (!empty($product_description['description'])) {
                $current_desc = strip_tags($product_description['description']);
                if (strlen($current_desc) > 200) {
                    $current_desc = substr($current_desc, 0, 200) . '...';
                }
                $prompt .= "Mevcut Açıklama: " . $current_desc . "\n";
            }
            
            $prompt .= "\nBu ürün için profesyonel, çekici ve SEO uyumlu bir ürün açıklaması ve Ürün Özelliklerini yaz. Açıklama Türkçe olsun, ürünün özelliklerini vurgulasın. Maksimum 500 kelime kullan.";
            
            error_log('Gemini\'ye gönderilecek prompt: ' . $prompt);
            
            $description = $this->callGeminiAPI($api_key, $prompt);
            
            if ($description) {
                $this->db->query("UPDATE " . DB_PREFIX . "product_description SET description = '" . $this->db->escape($description) . "' WHERE product_id = '" . (int)$product_id . "' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
                
                $json['success'] = 'Ürün açıklaması başarıyla oluşturuldu!';
                $json['description'] = $description;
                error_log('Başarılı: Açıklama oluşturuldu');
            } else {
                $json['error'] = 'Açıklama oluşturulamadı. API hatası. Log dosyasını kontrol edin.';
                error_log('Hata: API\'den yanıt alınamadı');
            }
            
        } catch (Exception $e) {
            $json['error'] = 'Hata: ' . $e->getMessage();
            error_log('Exception: ' . $e->getMessage());
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    private function callGeminiAPI($api_key, $prompt) {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' . $api_key;
        
        $data = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt)
                    )
                )
            ),
            'generationConfig' => array(
                'temperature' => 0.7,
                'topK' => 40,
                'topP' => 0.95,
                'maxOutputTokens' => 1024,
            )
        );
        
        // Debug için log yaz
        error_log('Gemini API Request URL: ' . $url);
        error_log('Gemini API Request Data: ' . json_encode($data));
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);
        
        // Debug için response'u log'a yaz
        error_log('Gemini API Response Code: ' . $http_code);
        error_log('Gemini API Response: ' . $response);
        error_log('Gemini API Curl Error: ' . $curl_error);
        
        if ($curl_error) {
            error_log('CURL Error: ' . $curl_error);
            return false;
        }
        
        if ($http_code == 200 && $response) {
            $result = json_decode($response, true);
            if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
                return $result['candidates'][0]['content']['parts'][0]['text'];
            } else {
                error_log('Gemini API: Unexpected response structure: ' . print_r($result, true));
            }
        } else {
            error_log('Gemini API HTTP Error: ' . $http_code . ' - ' . $response);
        }
        
        return false;
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/gemini_description')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['module_gemini_description_api_key']) {
            $this->error['api_key'] = $this->language->get('error_api_key');
        }

        return !$this->error;
    }

    public function install() {
        
    }

    public function uninstall() {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_gemini_description');
    }
}